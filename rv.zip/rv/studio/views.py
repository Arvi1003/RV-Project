from django.shortcuts import render
from .models import (
    Portfolio,
    Offer,
    BabyShootTheme,
    BabyShootPortfolio,
    Package,
    GalleryImage,
    BabyShootGallery
)

# Home view
def home(request):
    portfolio = Portfolio.objects.all()  # Fetch all portfolio items
    offers = Offer.objects.all()  # Fetch all offer items
    return render(request, 'studio/home.html', {'portfolio': portfolio, 'offers': offers})

def portfolio_view(request):
    portfolio = Portfolio.objects.all()  # Fetch all portfolio images
    return render(request, 'studio/portfolio.html', {'portfolio': portfolio})

# Baby shoot view
def baby_shoot(request):
    themes = BabyShootTheme.objects.all()  # Fetch all baby shoot themes
    portfolio_images = BabyShootPortfolio.objects.all()  # Fetch images from BabyShootPortfolio model
    packages = Package.objects.all()  # Fetch all packages

    return render(request, 'studio/baby_shoot.html', {
        'themes': themes,
        'portfolio_images': portfolio_images,
        'packages': packages  # Pass packages to the template
    })

def gallery(request):
    images = GalleryImage.objects.all()
    return render(request, 'studio/gallery.html', {'images': images})

def baby_shoot_gallery(request):
    baby_shoot_photos = BabyShootGallery.objects.all()  # Fetch all images
    return render(request, 'studio/baby_shoot_gallery.html', {'baby_shoot_photos': baby_shoot_photos})
