from django.db import models

class Portfolio(models.Model):
    image = models.ImageField(upload_to='portfolio_images/')

    def __str__(self):
        return self.image.name  # Returns the image file name as the string representation

class Offer(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='offers/', null=True, blank=True)
    start_date = models.DateField()
    end_date = models.DateField()

    def __str__(self):
        return self.title  # Returns the title as the string representation

class BabyShootTheme(models.Model):
    title = models.CharField(max_length=100)
    image = models.ImageField(upload_to='baby_shoot_themes/')

    def __str__(self):
        return self.title  # Returns the title as the string representation

class BabyShootPortfolio(models.Model):
    image = models.ImageField(upload_to='baby_shoot_portfolio/')

    def __str__(self):
        return self.image.name  # Returns the image file name as the string representation

class Package(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name  # Returns the name as the string representation

class GalleryImage(models.Model):
    image = models.ImageField(upload_to='gallery/')

    def __str__(self):
        return self.image.name  # Returns the image file name as the string representation

class BabyShootGallery(models.Model):
    image = models.ImageField(upload_to='baby_gallery/')  # Ensure you have a valid upload path

    def __str__(self):
        return self.image.name  # Returns the image file name as the string representation
