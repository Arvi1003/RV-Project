from django.contrib import admin
from .models import (
    Portfolio,
    Offer,
    BabyShootTheme,
    BabyShootPortfolio,
    Package,
    GalleryImage,
    BabyShootGallery
)

@admin.register(Portfolio)
class PortfolioAdmin(admin.ModelAdmin):
    list_display = ['image']
    # Since 'description' is removed, only display the 'image' field

@admin.register(Offer)
class OfferAdmin(admin.ModelAdmin):
    list_display = ['title', 'description', 'image', 'start_date', 'end_date']
    search_fields = ['title', 'description']
    list_filter = ['start_date', 'end_date']
    # All fields are retained as per the requirement

@admin.register(BabyShootTheme)
class BabyShootThemeAdmin(admin.ModelAdmin):
    fields = ['title', 'image']  # Removed 'description' field
    list_display = ['title', 'image']
    search_fields = ['title']

@admin.register(BabyShootPortfolio)
class BabyShootPortfolioAdmin(admin.ModelAdmin):
    list_display = ['image']
    # Since 'title' and 'description' are removed, only display the 'image' field

@admin.register(Package)
class PackageAdmin(admin.ModelAdmin):
    list_display = ['name', 'description', 'price']
    search_fields = ['name', 'description']
    list_filter = ['price']
    # All fields are retained as per the requirement

@admin.register(GalleryImage)
class GalleryImageAdmin(admin.ModelAdmin):
    list_display = ['image']
    # Since 'description' is removed, only display the 'image' field

@admin.register(BabyShootGallery)
class BabyShootGalleryAdmin(admin.ModelAdmin):
    list_display = ['image']
    # Since 'title' is removed, only display the 'image' field
