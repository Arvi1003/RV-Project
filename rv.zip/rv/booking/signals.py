from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail
from .models import Booking

@receiver(post_save, sender=Booking)
def send_booking_confirmation(sender, instance, created, **kwargs):
    if created:
        # Email to you about the new booking
        subject = 'New Booking Registered'
        message = (
            f'A new booking has been made:\n\n'
            f'Name: {instance.name}\n'
            f'Email: {instance.email}\n'
            f'Phone: {instance.phone}\n'
            f'Shoot Type: {instance.shoot_type}\n'
            f'Date: {instance.date}\n'
            f'Message: {instance.message}\n'
        )
        from_email = 'aravinthcraa@gmail.com'  # Your email
        recipient_list = ['aravinthcraa@gmail.com']  # Send to your email

        # Send the notification email to you
        send_mail(subject, message, from_email, recipient_list)

        # Thank-you email to the customer
        thank_you_subject = 'Thank You for Your Booking'
        thank_you_message = (
            f'Thank you {instance.name} for your booking!\n\n'
            f'We have received your request for \n'
            f'a {instance.shoot_type} on {instance.date}.\n'
            f'We will get back to you shortly.\n'
            f'Best Regards,\n'
            f'RV Photography'
        )
        thank_you_recipient_list = [instance.email]  # Send to the customer

        # Send the thank-you email to the customer
        send_mail(thank_you_subject, thank_you_message, from_email, thank_you_recipient_list)
