from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone

class Booking(models.Model):
    SHOOT_CHOICES = [
        ('Wedding', 'Wedding'),
        ('Baby Shoot', 'Baby Shoot'),
        ('Event', 'Event'),
    ]

    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    shoot_type = models.CharField(max_length=20, choices=SHOOT_CHOICES)
    date = models.DateField()
    message = models.TextField(blank=True)

    def clean(self):
        if self.date < timezone.now().date():
            raise ValidationError('The booking date cannot be in the past.')

    def __str__(self):
        return f'{self.name} ({self.email}) - {self.shoot_type} on {self.date}'
