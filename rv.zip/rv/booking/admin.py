from django.contrib import admin
from .models import Booking

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'shoot_type', 'date', 'message')  # Removed 'status'
    search_fields = ('name', 'email', 'phone')
    list_filter = ('shoot_type', 'date')  # Removed 'status'
    ordering = ('date',)
    date_hierarchy = 'date'
    readonly_fields = ('date',)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs
