from django.shortcuts import render, redirect
from .models import Booking
from .forms import BookingForm
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.conf import settings
from django.contrib import messages

def book_photoshoot(request):
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)  # Don't save yet
            booking.save()  # Now save the booking
            return redirect('booking_success')  # Redirect to the success URL using the named URL
    else:
        form = BookingForm()
    return render(request, 'booking/book_photoshoot.html', {'form': form})

def send_booking_email(request, booking):
    try:
        # Prepare context for the email
        context = {
            'package': booking.shoot_type,
            'date': booking.date,
            'customer_name': booking.name,
            'contact_number': booking.phone,
        }
        
        # Render HTML content for the email
        html_content = render_to_string('booking/notify.html', context)
        
        # Create email object
        email = EmailMultiAlternatives(
            subject='Booking Registered',
            body='Thank you for your booking!',  # This can be plain text or omitted
            from_email=settings.DEFAULT_FROM_EMAIL,  # Use a setting for the sender's email
            to=[booking.email]
        )
        email.attach_alternative(html_content, "text/html")

        # Send the email
        email.send()
        messages.success(request, "Confirmation email sent successfully.")

    except Exception as e:
        print(f"An error occurred while sending email: {e}")
        messages.error(request, "There was an issue sending the confirmation email.")



def booking_success(request):
    return render(request, 'booking/booking_success.html')
