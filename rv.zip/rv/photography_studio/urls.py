# photography_studio/urls.py

from django.contrib import admin
from django.urls import path, include
from studio import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views  # Import Django's built-in auth views

urlpatterns = [
    path('admin/logout/', auth_views.LogoutView.as_view(), name='admin_logout'),  # Explicit logout path
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('booking/', include('booking.urls')),
    path('baby-shoot/', views.baby_shoot, name='baby_shoot'),
    path('gallery/', views.gallery, name='gallery'),
    path('baby-shoot-gallery/', views.baby_shoot_gallery, name='baby_shoot_gallery'),
]

if settings.DEBUG:
    # Serve static files from STATICFILES_DIRS during development
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])
    # Serve media files from MEDIA_ROOT during development
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
