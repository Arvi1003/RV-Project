document.addEventListener("DOMContentLoaded", function () {
    const slides = document.querySelectorAll('.slide'); // Get all slides
    let currentSlide = 0;

    // Function to show a specific slide
    function showSlide(index) {
        slides.forEach((slide, i) => {
            slide.classList.remove('active'); // Remove active class from all slides
            if (i === index) {
                slide.classList.add('active'); // Add active class to the current slide
            }
        });
    }

    // Function to move to the next slide
    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length; // Loop back to the first slide
        showSlide(currentSlide);
    }

    // Initialize the slideshow
    showSlide(currentSlide);

    // Change slides every 3 seconds
    setInterval(nextSlide, 3000); // Change 3000 to adjust timing (milliseconds)
});

// Function to open the modal and display the clicked image
function openModal(imageUrl) {
    var modal = document.getElementById('imageModal');
    var modalImg = document.getElementById("modalImage");
    modal.style.display = "block";
    modalImg.src = imageUrl;
}

// Function to close the modal
function closeModal() {
    var modal = document.getElementById('imageModal');
    modal.style.display = "none";
}
