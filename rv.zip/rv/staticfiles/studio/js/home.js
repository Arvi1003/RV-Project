// Function to open the modal and display the clicked image
function openModal(imageUrl) {
    var modal = document.getElementById('imageModal');
    var modalImg = document.getElementById("modalImage");
    modal.style.display = "block";
    modalImg.src = imageUrl;
}

// Function to close the modal
function closeModal() {
    var modal = document.getElementById('imageModal');
    modal.style.display = "none";
}

// Toggle menu visibility
document.getElementById('menu-toggle').addEventListener('click', function() {
    const navUl = document.querySelector('nav ul');
    navUl.classList.toggle('active');
});

// Close menu when clicking on a menu item
document.querySelectorAll('nav ul li a').forEach(function(item) {
    item.addEventListener('click', function() {
        const navUl = document.querySelector('nav ul');
        navUl.classList.remove('active'); // Hide the menu
    });
});

// Close menu when clicking outside
window.addEventListener('click', function(event) {
    const navUl = document.querySelector('nav ul');
    const menuToggle = document.getElementById('menu-toggle');
    if (!navUl.contains(event.target) && !menuToggle.contains(event.target)) {
        navUl.classList.remove('active'); // Hide the menu
    }
});
